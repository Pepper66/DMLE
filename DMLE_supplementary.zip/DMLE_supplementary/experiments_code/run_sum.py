#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import json
import os
from typing import Any, Dict, List, Tuple

import numpy as np

from easyeditor import (
    IKEHyperParams,
    MEMITHyperParams,
    ROMEHyperParams,
    LoRAHyperParams,
    GraceHyperParams,
)
from easyeditor import BaseEditor

from easyeditor.editors.utils import _prepare_requests
from easyeditor.evaluate.evaluate_utils import llm_judge

# More robust import for compute_edit_quality across different EasyEdit forks
try:
    from easyeditor.evaluate.evaluate import compute_edit_quality
except Exception:
    from easyeditor.evaluate import compute_edit_quality


# -------------------------
# 1) Summary printing
# -------------------------
def _safe_mean(x: Any) -> float:
    try:
        arr = np.array(x, dtype=float)
        if arr.size == 0:
            return float("nan")
        return float(np.mean(arr))
    except Exception:
        return float("nan")


def eval_summary(metrics_path: str) -> None:
    if not os.path.exists(metrics_path):
        print("[eval] file not found:", metrics_path)
        return
    with open(metrics_path, "r") as f:
        datas = json.load(f)

    rewrite_list = []
    rephrase_list = []

    for d in datas:
        ra = d.get("post", {}).get("rewrite_acc", None)
        if isinstance(ra, list) and len(ra) > 0:
            rewrite_list.append(float(ra[0]))
        elif ra is not None:
            rewrite_list.append(float(ra))

        rpa = d.get("post", {}).get("rephrase_acc", None)
        if isinstance(rpa, list) and len(rpa) > 0:
            rephrase_list.append(float(rpa[0]))
        elif rpa is not None:
            rephrase_list.append(float(rpa))

    if len(rewrite_list) > 0:
        print("Edit_Succ:", np.mean(rewrite_list) * 100.0)
    if len(rephrase_list) > 0:
        print("Overall_generality:", np.mean(rephrase_list) * 100.0)

    locality_case_scores = []
    for d in datas:
        loc = d.get("post", {}).get("locality", {})
        per_case = []
        for k, v in loc.items():
            if k.endswith("_acc"):
                per_case.append(_safe_mean(v) * 100.0)
        if len(per_case) > 0:
            locality_case_scores.append(float(np.mean(per_case)))
    if len(locality_case_scores) > 0:
        print("Overall_locality:", float(np.mean(locality_case_scores)))

    inst_scores = []
    rule_scores = []
    for d in datas:
        por = d.get("post", {}).get("portability", {})
        if "Instance_acc" in por:
            inst_scores.append(_safe_mean(por["Instance_acc"]) * 100.0)
        if "Rule_acc" in por:
            rule_scores.append(_safe_mean(por["Rule_acc"]) * 100.0)

    if len(inst_scores) > 0:
        print("Instance_portability:", float(np.mean(inst_scores)))
    if len(rule_scores) > 0:
        print("Rule_understanding:", float(np.mean(rule_scores)))


# -------------------------
# 2) Build inputs
# -------------------------
def build_inputs_from_dataset(dataset: List[Dict]) -> Tuple:
    prompts, subjects, ground_truths, target_news, rephrase_prompts = [], [], [], [], []
    neighborhood_prompts, neighborhood_truths = [], []
    distracting_prompts, distracting_truths = [], []
    instance_prompts, instance_truths = [], []
    rule_prompts, rule_truths = [], []

    for data in dataset:
        prompts.append(data["prompt"])
        subjects.append(data["subject"])
        ground_truths.append(data["ground_truth"] if "ground_truth" in data else "")
        target_news.append(data["target_new"])
        rephrase_prompts.append(data.get("rephrase_prompt", ""))

        neighborhood_prompts.append(data["locality"]["neighborhood"]["prompt"])
        neighborhood_truths.append(data["locality"]["neighborhood"]["ground_truth"])
        distracting_prompts.append(data["locality"]["distracting"]["prompt"])
        distracting_truths.append(data["locality"]["distracting"]["ground_truth"])

        instance_prompts.append(data["Instance"]["prompt"])
        instance_truths.append(data["Instance"]["target_new"])
        rule_prompts.append(data["Rule_Understanding"]["prompt"])
        rule_truths.append(data["Rule_Understanding"]["target_new"])

    locality_inputs = {
        "neighborhood": {"prompt": neighborhood_prompts, "ground_truth": neighborhood_truths},
        "distracting": {"prompt": distracting_prompts, "ground_truth": distracting_truths},
    }
    portability_inputs = {
        "Instance": {"prompt": instance_prompts, "ground_truth": instance_truths},
        "Rule": {"prompt": rule_prompts, "ground_truth": rule_truths},
    }

    return (
        prompts,
        subjects,
        ground_truths,
        target_news,
        rephrase_prompts,
        locality_inputs,
        portability_inputs,
    )


def load_json(path: str) -> Any:
    with open(path, "r") as f:
        return json.load(f)


# -------------------------
# 3) True batch edit via apply_algo
# -------------------------
def batch_apply_one_stage(editor: BaseEditor, hparams, stage_requests: List[Dict]) -> None:
    edited_model, _weights_copy = editor.apply_algo(
        editor.model,
        editor.tok,
        stage_requests,
        hparams,
        copy=False,
        return_orig_weights=False,
        keep_original_weight=False,
        train_ds=None,
    )
    editor.model = edited_model


# -------------------------
# 4) Locality output -> acc (Scheme A)
# -------------------------



def prepare_requests_compat(
    prompts,
    target_new,
    ground_truth,
    rephrase_prompts,
    locality_inputs,
    portability_inputs,
    subjects,
):
    """
    Some EasyEdit forks accept subject= in _prepare_requests, some do not.
    We try with subject= first, then fallback.
    """
    try:
        return _prepare_requests(
            prompts=prompts,
            target_new=target_new,
            ground_truth=ground_truth,
            target_neg=None,
            rephrase_prompts=rephrase_prompts,
            locality_inputs=locality_inputs,
            portability_inputs=portability_inputs,
            subject=subjects,
        )
    except TypeError:
        return _prepare_requests(
            prompts=prompts,
            target_new=target_new,
            ground_truth=ground_truth,
            target_neg=None,
            rephrase_prompts=rephrase_prompts,
            locality_inputs=locality_inputs,
            portability_inputs=portability_inputs,
        )


def calculate_final_grand_average(metrics_files: List[str]):
    """
    读取所有规则的结果文件，计算大平均值并打印表格
    """
    all_summaries = []

    # 模拟 eval_summary 的逻辑来提取数值
    for path in metrics_files:
        if not os.path.exists(path): continue
        with open(path, "r") as f:
            datas = json.load(f)

        # 提取当前规则的各项平均指标
        rewrite_list = [float(
            d["post"].get("rewrite_acc", [0])[0] if isinstance(d["post"].get("rewrite_acc"), list) else d["post"].get(
                "rewrite_acc", 0)) for d in datas]
        rephrase_list = [float(
            d["post"].get("rephrase_acc", [0])[0] if isinstance(d["post"].get("rephrase_acc"), list) else d["post"].get(
                "rephrase_acc", 0)) for d in datas]

        loc_scores = []
        for d in datas:
            loc = d["post"].get("locality", {})
            per_case = [_safe_mean(v) * 100.0 for k, v in loc.items() if k.endswith("_acc")]
            if per_case: loc_scores.append(np.mean(per_case))

        inst_scores = [_safe_mean(d["post"].get("portability", {}).get("Instance_acc", 0)) * 100.0 for d in datas]
        rule_scores = [_safe_mean(d["post"].get("portability", {}).get("Rule_acc", 0)) * 100.0 for d in datas]

        all_summaries.append({
            "Edit_Succ": np.mean(rewrite_list) * 100.0,
            "Generality": np.mean(rephrase_list) * 100.0,
            "Locality": np.mean(loc_scores) if loc_scores else 0,
            "Portability": np.mean(inst_scores),
            "Rule_Logic": np.mean(rule_scores)
        })

    # 打印对比表格
    print("\n" + "=" * 85)
    print(f"{'Rule_Folder':<15} | {'Succ':<8} | {'Gen':<8} | {'Loc':<8} | {'Port':<8} | {'Logic':<8}")
    print("-" * 85)

    averages = {k: [] for k in all_summaries[0].keys()}
    for i, s in enumerate(all_summaries):
        print(
            f"Rule_{i:<10} | {s['Edit_Succ']:<8.2f} | {s['Generality']:<8.2f} | {s['Locality']:<8.2f} | {s['Portability']:<8.2f} | {s['Rule_Logic']:<8.2f}")
        for k, v in s.items(): averages[k].append(v)

    print("-" * 85)
    print(
        f"{'GRAND AVERAGE':<15} | {np.mean(averages['Edit_Succ']):<8.2f} | {np.mean(averages['Generality']):<8.2f} | {np.mean(averages['Locality']):<8.2f} | {np.mean(averages['Portability']):<8.2f} | {np.mean(averages['Rule_Logic']):<8.2f}")
    print("=" * 85 + "\n")

# -------------------------
# 5) Main
# -------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--editing_method", type=str, default="")
    parser.add_argument("--hparams_dir", type=str, default="")
    parser.add_argument("--metrics_save_dir", type=str, default="")
    parser.add_argument("--rule_edit", default=True, type=str)
    parser.add_argument("--evaluation_type", default="LLM-judge", type=str)
    parser.add_argument("--api_key", default="", type=str)

    parser.add_argument(
        "--stages",
        type=str,
        default="",
        help="JSON file path or JSON string of stages",
    )
    parser.add_argument(
        "--union_save_name",
        type=str,
        default="",
        help="final union metrics filename",
    )
    args = parser.parse_args()

    # select hparams
    if args.editing_method == "IKE":
        editing_hparams = IKEHyperParams
    elif args.editing_method == "ICE":
        editing_hparams = IKEHyperParams
    elif args.editing_method == "MEMIT":
        editing_hparams = MEMITHyperParams
    elif args.editing_method == "ROME":
        editing_hparams = ROMEHyperParams
    elif args.editing_method == "LoRA":
        editing_hparams = LoRAHyperParams
    elif args.editing_method == "GRACE":
        editing_hparams = GraceHyperParams
    else:
        raise NotImplementedError(args.editing_method)

    hparams = editing_hparams.from_hparams(args.hparams_dir)
    hparams.fp16 = True
    hparams.rule_edit = args.rule_edit
    hparams.evaluation_type = args.evaluation_type
    if args.api_key is not None:
        hparams.api_key = args.api_key

    base_data_dir = "../struct_data"
    rule_folders = [f for f in os.listdir(base_data_dir) if os.path.isdir(os.path.join(base_data_dir, f))]
    rule_folders.sort()  # 确保按 0, 1, 2... 顺序执行

    all_rule_summaries = [] # 用于存储每条规则的最终汇总结果

    for folder in rule_folders:
        print(f"\n{'=' * 20} Processing Rule: {folder} {'=' * 20}")
        current_dir = os.path.join(base_data_dir, folder)
        config_path = os.path.join(current_dir, "config.json")

        if not os.path.exists(config_path):
            continue

         # 先构造输出路径（必须在 skip 判断前）
        rule_output_path = os.path.join(args.metrics_save_dir, f"metrics_rule_{folder}.json")
        if os.path.exists(rule_output_path):
            print(f"[SKIP] Found existing metrics: {rule_output_path} -> skip rule {folder}")
            all_rule_summaries.append(rule_output_path)
            continue

        editor = BaseEditor.from_hparams(hparams)

        # parse stages

        stages = load_json(config_path)

        assert isinstance(stages, list) and len(stages) > 0
        for s in stages:
            assert "data" in s and "layers" in s, "Each stage must have keys: data, layers"

        # union dataset = concat all stage datasets in given order
        union_dataset: List[Dict] = []
        for s in stages:
            ds = load_json(s["data"])
            if not isinstance(ds, list):
                raise ValueError("dataset must be a list, got %s from %s" % (type(ds), s["data"]))
            union_dataset.extend(ds)

        (
            u_prompts,
            u_subjects,
            u_ground_truths,
            u_target_news,
            u_rephrase_prompts,
            u_locality_inputs,
            u_portability_inputs,
        ) = build_inputs_from_dataset(union_dataset)

        union_requests = prepare_requests_compat(
            prompts=u_prompts,
            target_new=u_target_news,
            ground_truth=u_ground_truths,
            rephrase_prompts=u_rephrase_prompts,
            locality_inputs=u_locality_inputs,
            portability_inputs=u_portability_inputs,
            subjects=u_subjects,
        )

        print("[INFO] stages =", len(stages))
        for i, s in enumerate(stages):
            print("[INFO] stage", i, "data=", s["data"], "layers=", s["layers"])

        # PRE cache on union
        print("[INFO] PRE evaluate on UNION (original model) ...")
        pre_cache = []
        for req in union_requests:
            pre = compute_edit_quality(
                editor.model,
                hparams.model_name,
                hparams,
                editor.tok,
                req,
                hparams.device,
                eval_metric="exact match",
                test_generation=False,
            )
            pre_cache.append(pre)

        # multi-stage cumulative batch edit
        print("[INFO] Start multi-stage cumulative BATCH editing ...")
        for stage_id, st in enumerate(stages):
            data_path = st["data"]
            layers = st["layers"]

            hparams.layers = layers
            if hasattr(hparams, "layer_selection"):
                hparams.layer_selection = "manual"

            stage_dataset = load_json(data_path)

            (
                prompts,
                subjects,
                ground_truths,
                target_news,
                rephrase_prompts,
                locality_inputs,
                portability_inputs,
            ) = build_inputs_from_dataset(stage_dataset)

            stage_requests = prepare_requests_compat(
                prompts=prompts,
                target_new=target_news,
                ground_truth=ground_truths,
                rephrase_prompts=rephrase_prompts,
                locality_inputs=locality_inputs,
                portability_inputs=portability_inputs,
                subjects=subjects,
            )

            print("--- Stage", stage_id, "---")
            print("data:", data_path)
            print("layers:", layers)
            print("requests:", len(stage_requests))

            batch_apply_one_stage(editor, hparams, stage_requests)

        # POST on union
        print("[INFO] POST evaluate on UNION (final edited model) ...")
        post_list = []
        for req in union_requests:
            post = compute_edit_quality(
                editor.model,
                hparams.model_name,
                hparams,
                editor.tok,
                req,
                hparams.device,
                eval_metric="exact match",
                test_generation=False,
            )
            post_list.append(post)

        # merge metrics + locality output->acc (Scheme A)
        rule_metrics: List[Dict] = []
        for i, req in enumerate(union_requests):
            pre = pre_cache[i]
            post = post_list[i]

            if isinstance(post, dict) and "locality" in post and isinstance(post["locality"], dict):
                post_loc = post["locality"]
                new_loc = {}

                # req["locality"] 的结构：
                # req["locality"]["neighborhood"]["prompt"] -> list[str]
                # req["locality"]["neighborhood"]["ground_truth"] -> list[str]
                for loc_name in ["neighborhood", "distracting"]:
                    out_key = f"{loc_name}_output"
                    if out_key not in post_loc:
                        continue

                    preds = post_loc[out_key]  # list[str]
                    qs = req["locality"][loc_name]["prompt"]
                    gts = req["locality"][loc_name]["ground_truth"]

                    accs = []
                    for q, gt, pred in zip(qs, gts, preds):
                        accs.append(llm_judge(q, gt, pred, hparams.api_key))  # 0/1

                    # 保留文本输出 + 新增 acc
                    new_loc[out_key] = preds
                    new_loc[f"{loc_name}_acc"] = accs

                post["locality"] = new_loc

                # pre 里的 locality 不再需要，避免后面误用
                if isinstance(pre, dict):
                    pre.pop("locality", None)


            rule_metrics.append(
                {
                    "case_id": i,
                    "requested_rewrite": req,
                    "pre": pre,
                    "post": post,
                }
            )

        #rule_output_path = os.path.join(args.metrics_save_dir, f"metrics_rule_{folder}.json")
        os.makedirs(args.metrics_save_dir, exist_ok=True)
        with open(rule_output_path, "w") as f:
            json.dump(rule_metrics, f, indent=2, ensure_ascii=False)
        # 记录汇总信息（用于最后的平均值计算）
        all_rule_summaries.append(rule_output_path)
        print(f">>> 规则 {folder} 完成。指标摘要:")
        eval_summary(rule_output_path)

    # 6. 计算所有规则的总平均值并展示表格
    calculate_final_grand_average(all_rule_summaries)


    # print("[INFO] Saved UNION metrics to:", out_path)
    # print("[INFO] UNION summary:")
    # eval_summary(out_path)


if __name__ == "__main__":
    main()
